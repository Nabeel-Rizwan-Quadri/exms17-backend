const mongoose = require("mongoose")

mongoose.connect('mongodb+srv://admin:admin@cluster0.slacs61.mongodb.net/DB1?retryWrites=true&w=majority')

module.exports = mongoose